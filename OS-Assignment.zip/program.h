#ifndef PROGRAM_H
#define PROGRAM_H
void beginSimulation(int bufferSize, int liftTime);
#endif
